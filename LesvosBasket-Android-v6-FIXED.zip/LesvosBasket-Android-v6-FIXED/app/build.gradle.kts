plugins {
    id("com.android.application")
}

android {
    namespace = "gr.lesvosbasket.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "gr.lesvosbasket.app"
        minSdk = 24
        targetSdk = 36
        versionCode = 6
        versionName = "1.0.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
