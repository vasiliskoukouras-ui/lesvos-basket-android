package gr.lesvosbasket.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String HOME = "https://lesvos-basket.netlify.app/";
    private static final String FALLBACK = "file:///android_asset/site/index.html";
    private WebView webView;
    private ProgressBar progress;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean pageReady = false;
    private boolean usingFallback = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8, 27, 58));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 27, 58));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        status = new TextView(this);
        status.setText("Lesvos Basket\nΦόρτωση…");
        status.setTextColor(Color.WHITE);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setPadding(32, 32, 32, 32);
        status.setBackgroundColor(Color.rgb(8, 27, 58));

        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(status, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, 8);
        root.addView(progress, pp);
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadsImagesAutomatically(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setUserAgentString(s.getUserAgentString() + " LesvosBasketAndroid/1.0.1");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                String host = u.getHost();
                if ("file".equals(scheme)) return false;
                if (host != null && (host.equals("lesvos-basket.netlify.app") ||
                        host.equals("lesvosbasket.gr") || host.endsWith(".lesvosbasket.gr"))) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
                catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageReady = true;
                status.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req,
                                        android.webkit.WebResourceError error) {
                if (req.isForMainFrame()) loadFallback();
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest req,
                                            WebResourceResponse response) {
                if (req.isForMainFrame() && response.getStatusCode() >= 400) loadFallback();
            }
        });

        if (savedInstanceState == null) {
            loadOnline();
        } else {
            webView.restoreState(savedInstanceState);
            status.setVisibility(View.GONE);
        }
    }

    private void loadOnline() {
        pageReady = false;
        usingFallback = false;
        status.setText("Lesvos Basket\nΦόρτωση…");
        status.setVisibility(View.VISIBLE);
        webView.loadUrl(HOME);
        handler.postDelayed(() -> {
            if (!pageReady && !usingFallback) loadFallback();
        }, 12000);
    }

    private void loadFallback() {
        if (usingFallback) return;
        usingFallback = true;
        pageReady = false;
        status.setText("Lesvos Basket\nΦόρτωση τοπικού αντιγράφου…");
        status.setVisibility(View.VISIBLE);
        webView.loadUrl(FALLBACK);
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
