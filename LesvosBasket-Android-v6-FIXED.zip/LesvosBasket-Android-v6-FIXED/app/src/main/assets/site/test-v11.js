const assert=require('assert'); const {calculateStandings,auditStandings}=require('./standings-engine'); const {evaluate}=require('./release-gate');
const games=[{home_team:'A',away_team:'B',home_score:70,away_score:60,status:'final',verification_status:'verified'},{home_team:'B',away_team:'A',home_score:80,away_score:75,status:'final',verification_status:'verified'}];
let s=calculateStandings(games,[{team:'B',points_delta:-1,verification_status:'verified'}]); assert.equal(s.find(x=>x.team==='B').points,2); assert.equal(s.find(x=>x.team==='A').points,3);
assert.equal(auditStandings(s,[{team:'A',played:2,wins:1,losses:1,points:3}]).ok,true);
assert.equal(evaluate({games:[{id:'x',public:true,verification_status:'pending_review'}]}).status,'BLOCKED');
assert.equal(evaluate({games:[{id:'x',public:true,verification_status:'verified',source_url:'https://example.org'}]}).status,'PASS');
console.log('v11 integrity tests: PASS');
