/** Lesvos Basket v4 importer core.
 * Source-first: parsers return candidates; they never auto-publish.
 */
export function normalizeTeamName(value='') {
  return value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase()
    .replace(/[.–—-]/g,' ').replace(/\s+/g,' ').trim();
}
export function candidateGame({home,away,homeScore=null,awayScore=null,sourceUrl,publishedAt=null}) {
  if (!home || !away || !sourceUrl) throw new Error('Missing required source/game fields');
  const scoreOK = [homeScore,awayScore].every(v => v === null || (Number.isInteger(v) && v >= 0 && v < 250));
  return {
    home, away, normalizedHome: normalizeTeamName(home), normalizedAway: normalizeTeamName(away),
    homeScore, awayScore, sourceUrl, publishedAt,
    verificationStatus: scoreOK ? 'pending_review' : 'rejected',
    publishable: false
  };
}
export function validatePeriods(periods, homeScore, awayScore) {
  const h=periods.reduce((a,p)=>a+(p.home||0),0), a=periods.reduce((s,p)=>s+(p.away||0),0);
  return {ok:h===homeScore && a===awayScore, calculated:[h,a]};
}
