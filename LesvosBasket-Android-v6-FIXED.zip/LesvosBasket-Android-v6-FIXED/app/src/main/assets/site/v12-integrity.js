(function(root){
  function audit(data){
    const errors=[];
    const ids=new Set();
    for(const g of data.verified_games||[]){
      if(ids.has(g.id)) errors.push({type:'duplicate_game_id',id:g.id}); ids.add(g.id);
      if(g.verification_status!=='verified') errors.push({type:'unverified_public_game',id:g.id});
      if(!/^https:\/\/(www\.)?(basket\.gr|lesvosbasket\.gr)\//.test(g.source_url||'')) errors.push({type:'non_official_source',id:g.id});
      if(!Number.isInteger(g.home_score)||!Number.isInteger(g.away_score)||g.home_score<0||g.away_score<0) errors.push({type:'invalid_score',id:g.id});
      if(Array.isArray(g.periods)){
        const h=g.periods.reduce((s,p)=>s+p[0],0), a=g.periods.reduce((s,p)=>s+p[1],0);
        if(h!==g.home_score||a!==g.away_score) errors.push({type:'period_total_mismatch',id:g.id,period_total:[h,a],final:[g.home_score,g.away_score]});
      }
    }
    for(const p of data.verified_player_lines||[]){
      if(p.coverage!=='single_verified_match') errors.push({type:'unsafe_player_coverage_claim',player:p.player});
      if(p.identity_status!=='verified' && (p.eok_profile_url||p.photo_url)) errors.push({type:'unsafe_identity_link',player:p.player});
    }
    return {ok:errors.length===0,release:errors.length?'BLOCKED':'PASS',errors};
  }
  const api={audit}; if(typeof module!=='undefined') module.exports=api; root.LesvosV12Integrity=api;
})(typeof window!=='undefined'?window:globalThis);
