import {resolveOfficialEvidence} from './conflict-engine.js';
export function validatePublicGame(g){const e=[];if(!g.source)e.push('missing_source');if(!Number.isInteger(g.hs)||!Number.isInteger(g.as)||g.hs<0||g.as<0)e.push('invalid_score');return e}
export function validatePeriods(periods,finalScore){if(!Array.isArray(periods)||!periods.length)return {status:'not_available'};const sum=periods.reduce((a,x)=>a+Number(x||0),0);return {status:sum===finalScore?'pass':'fail',sum}}
export function validatePlayerPublication(p){const e=[];if(!p.source)e.push('missing_source');if(p.identity_status!=='verified'&&(p.eokProfile||p.photo))e.push('unsafe_identity_asset');if(p.coverage!=='complete'&&p.presentation==='season_total')e.push('partial_as_total');return e}
export {resolveOfficialEvidence};
