const fs=require('fs');
const d=JSON.parse(fs.readFileSync(__dirname+'/v14-data.json','utf8'));
let errors=[];
if(d.policy!=='fail-closed') errors.push('policy');
for(const t of d.teams){ if(!t.name||!['partial','complete'].includes(t.coverage)) errors.push('team:'+t.name); }
for(const c of d.coverage){ if(!c.season||!c.competition||!c.note) errors.push('coverage'); }
for(const k of ['require_official_source','block_image_only_numeric_import','block_unresolved_conflicts','block_unverified_identity_links']) if(d.release_gate[k]!==true) errors.push('gate:'+k);
console.log(errors.length?`FAIL ${errors.join(', ')}`:'PASS v14 integrity — 0 critical errors');
process.exit(errors.length?1:0);
