export function validateGame(game) {
  const errors = [];
  if (!game.homeTeam || !game.awayTeam) errors.push('Λείπει ομάδα.');
  if (game.homeTeam === game.awayTeam) errors.push('Η ίδια ομάδα δεν μπορεί να είναι γηπεδούχος και φιλοξενούμενη.');
  if (game.status === 'final' && (!Number.isInteger(game.homeScore) || !Number.isInteger(game.awayScore))) errors.push('Τελικός αγώνας χωρίς έγκυρο σκορ.');
  if ([game.homeScore, game.awayScore].some(v => v != null && (v < 0 || v > 250))) errors.push('Μη ρεαλιστικό σκορ — απαιτείται έλεγχος.');
  if (!game.sourceUrl) errors.push('Λείπει URL επίσημης πηγής.');
  return errors;
}

export function validateBoxScore(rows, teamScore) {
  const errors = [];
  for (const r of rows) {
    const computed = (r.ftMade ?? 0) + 2 * (r.twoMade ?? 0) + 3 * (r.threeMade ?? 0);
    if (r.points != null && r.hasCompleteShooting && computed !== r.points) {
      errors.push(`${r.player}: οι πόντοι (${r.points}) δεν συμφωνούν με 1Π/2Π/3Π (${computed}).`);
    }
  }
  const total = rows.reduce((s,r) => s + (r.points ?? 0), 0);
  if (teamScore != null && rows.every(r => r.points != null) && total !== teamScore) {
    errors.push(`Άθροισμα παικτών ${total}, τελικό σκορ ομάδας ${teamScore}.`);
  }
  return errors;
}

export function decideVerification(evidence) {
  const official = evidence.filter(x => x.isOfficial && x.sourceUrl);
  if (!official.length) return 'pending_review';
  const finals = official.filter(x => x.status === 'final');
  const scores = new Set(finals.map(x => `${x.homeScore}-${x.awayScore}`));
  if (scores.size > 1) return 'source_conflict';
  // Auto-verification only when at least two official evidence records agree.
  if (finals.length >= 2 && scores.size === 1) return 'verified';
  return 'pending_review';
}
