# Lesvos Basket MVP v19

Evidence-maturity hardening build.

- Adds an evidence maturity layer above the existing provenance ledger.
- Official text results/box scores rank above schedules and image-only numeric posts.
- Image-only numeric posts remain REVIEW_REQUIRED and cannot enter the verified score ledger automatically.
- Adds same-team, missing-score and weak-evidence release checks.
- Keeps the 12/09/2026 TE Lesvos result post review-only because retrievable official text does not expose a safe score.
- Retains explicit PARTIAL coverage semantics; no partial dataset is represented as a complete season.

Policy: fail closed; uncertainty blocks promotion, not the entire archive.
