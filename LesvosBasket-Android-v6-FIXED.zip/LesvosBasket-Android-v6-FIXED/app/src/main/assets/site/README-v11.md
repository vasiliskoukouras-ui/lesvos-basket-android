# Lesvos Basket MVP v11

## New in v11
- Deterministic standings engine with explicit verified point adjustments / penalties.
- Official-vs-calculated standings audit; mismatches become review issues, never silent corrections.
- Fail-closed release gate for public games, unresolved source conflicts, critical integrity issues and unsafe EOK player/profile/photo links.
- Additional verified 2025-26 facts stored in `v11-data.json`.
- Regression tests in `test-v11.js`.

## Accuracy rule
The system is designed to minimize errors, but cannot promise literal zero error because official sources themselves can be corrected or conflict. Uncertain data is blocked from normal publication.

Run: `node test-v11.js`
