# Lesvos Basket MVP v15

## Team Profiles
- Dynamic team profiles are derived only from verified public-layer games, verified titles, and source-backed player match entries.
- Every team is marked PARTIAL unless completeness is independently established.
- Team KPIs explicitly count only games present in the current verified dataset.
- Canonical team aliases prevent obvious naming variants from splitting the same club in the UI.
- Each verified game/title retains a direct official source link.

## Accuracy rules
- No image-only numeric standings are promoted automatically.
- No unverified player identity is linked to an EOK profile.
- Unknown data is never converted to zero.
- Partial coverage is never presented as a full season or club history.
