const fs=require('fs'),vm=require('vm');
const js=fs.readFileSync('app.js','utf8');
const start=js.indexOf('// v18 —');
if(start<0) throw new Error('v18 module missing');
const v18=js.slice(start);
for(const token of ['semantic-duplicate','verified-without-source','unreviewed-promoted','Data Safety Gate']) if(!v18.includes(token)) throw new Error('missing '+token);
console.log('PASS v18 static integrity checks');
