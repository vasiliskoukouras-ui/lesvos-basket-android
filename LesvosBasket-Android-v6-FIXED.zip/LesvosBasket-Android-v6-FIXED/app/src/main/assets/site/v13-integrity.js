(function(root){
 function sumPeriods(periods){return (periods||[]).reduce((a,p)=>[a[0]+p[0],a[1]+p[1]],[0,0]);}
 function audit(data){
   const errors=[], warnings=[], ids=new Set();
   (data.verified_games||[]).forEach(g=>{
     if(ids.has(g.id)) errors.push(`${g.id}: duplicate id`); ids.add(g.id);
     if(g.verification_status!=='verified') errors.push(`${g.id}: public game is not verified`);
     if(!/^https:\/\/(www\.)?(basket\.gr|lesvosbasket\.gr)\//.test(g.source_url||'')) errors.push(`${g.id}: source is not approved official domain`);
     if(!Number.isInteger(g.home_score)||!Number.isInteger(g.away_score)||g.home_score<0||g.away_score<0) errors.push(`${g.id}: invalid score`);
     if(g.periods){const s=sumPeriods(g.periods); if(s[0]!==g.home_score||s[1]!==g.away_score) errors.push(`${g.id}: period sum ${s.join('-')} != final ${g.home_score}-${g.away_score}`);}
   });
   (data.verified_facts||[]).forEach(f=>{if(f.verification_status!=='verified') errors.push(`fact ${f.competition}: not verified`);if(f.cross_source&&(!f.sources||f.sources.length<2)) errors.push(`fact ${f.competition}: cross-source flag without 2 sources`);});
   return {release:errors.length===0,errors,warnings};
 }
 root.LesvosV13Integrity={audit,sumPeriods};
})(typeof window!=='undefined'?window:globalThis);
