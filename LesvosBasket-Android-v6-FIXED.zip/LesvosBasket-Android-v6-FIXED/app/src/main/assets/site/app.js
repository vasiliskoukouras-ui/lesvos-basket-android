const officialMatches=[
{id:'men-2425',season:'2024–25',competition:'Πρωτάθλημα Ανδρών',date:'07/04/2025',home:'Α.Π.Σ. Παπάδου Γέρας',away:'Παλλεσβιακός Π.Γ.',hs:76,as:85,note:'Ο Παλλεσβιακός κατέκτησε το Πρωτάθλημα Ανδρών 2024–25.',source:'https://lesvosbasket.gr/apotelesma-agona-07-04-25/'},
{id:'cup-2526',season:'2025–26',competition:'Κύπελλο Ανδρών «Γ. Καρέκος»',date:'19/10/2025',home:'Αθλητική Λέσχη Μυτιλήνης',away:'Παλλεσβιακός Π.Γ.',hs:62,as:67,note:'Ο Παλλεσβιακός αναδείχθηκε Κυπελλούχος Ανδρών 2025–26.',source:'https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-18-19-10-25/'}
];
const tournament=[
['25/10/2025 · 13:00','ΕΚΑΣΔ','ΤΕ Λέσβου','https://www.youtube.com/watch?v=EkFKIogzTLo'],['25/10/2025 · 19:30','ΤΕ Λέσβου','ΕΣΚΚ','https://www.youtube.com/watch?v=LmeTiuWz9O0'],['26/10/2025 · 18:00','ΤΕ Λέσβου','ΤΕ Σάμου','https://www.youtube.com/watch?v=TVHUXOebcA4'],['27/10/2025 · 09:30','ΤΕ Λέσβου','ΤΕ Χίου','https://www.youtube.com/watch?v=AKbTqjyuurs']];
const entities=['Παλλεσβιακός Π.Γ.','Αθλητική Λέσχη Μυτιλήνης','Α.Π.Σ. Παπάδου Γέρας','Α.Ο. Ήφαιστος Λήμνου','Ε.Γ.Σ. Αίολος Μυτιλήνης','Τ.Ε. Λέσβου'];
const seasons=[
{season:'2025–26',status:'Μερικό αρχείο',items:[['Κύπελλο Ανδρών','Παλλεσβιακός · 62–67 στον τελικό','https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-18-19-10-25/'],['Εφήβων','Πρωταθλητής: Α.Ο. Ήφαιστος Λήμνου','https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-28-02-01-03-26/'],['Νεανίδων','Νικήτρια τελικού: Ε.Γ.Σ. Αίολος Μυτιλήνης','https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-31-01-01-02-26/']]},
{season:'2024–25',status:'Μερικό αρχείο',items:[['Ανδρών','Πρωταθλητής: Παλλεσβιακός Π.Γ. · 76–85 στον τελευταίο αγώνα','https://lesvosbasket.gr/apotelesma-agona-07-04-25/'],['Εφήβων','Πρωταθλητής: Α.Ο. Ήφαιστος Λήμνου','https://lesvosbasket.gr/apotelesmata-agonon-08-09-03-25/']]},
{season:'2023–24',status:'Υπό ψηφιοποίηση',items:[['Διοργανώσεις','Ανδρών, Γυναικών, Εφήβων, Νεανίδων, Κορασίδων, Παίδων, Κύπελλο Ανδρών','https://lesvosbasket.gr/kliroseis-protathlimaton-2023-2024/']]},
{season:'2022–23',status:'Χαρτογράφηση',items:[]},{season:'2021–22',status:'Χαρτογράφηση',items:[]}
];
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function renderGames(){const sf=document.querySelector('#seasonFilter').value,cf=document.querySelector('#competitionFilter').value;let arr=officialMatches.filter(m=>(sf.startsWith('Όλες')||m.season===sf)&&(cf.startsWith('Όλες')||m.competition.includes(cf.replace('Κύπελλο Ανδρών','Κύπελλο Ανδρών'))));document.querySelector('#gameCards').innerHTML=arr.length?arr.map(m=>`<article class="card verified-card"><div class="card-top"><span class="tag">${esc(m.competition)}</span><span class="verified">✓ VERIFIED</span></div><div class="meta">${esc(m.date)} · ${esc(m.season)}</div><div class="match"><div class="team-name">${esc(m.home)}</div><div class="score-wrap"><div class="score">${m.hs}<span>–</span>${m.as}</div><span class="status">Τελικό</span></div><div class="team-name">${esc(m.away)}</div></div><div class="source"><a href="${m.source}" target="_blank" rel="noopener">Επίσημη πηγή ↗</a></div></article>`).join(''):'<div class="empty-panel"><h3>Δεν υπάρχουν verified εγγραφές για αυτό το φίλτρο.</h3><p>Δεν συμπληρώνουμε κενά με μη επιβεβαιωμένα δεδομένα.</p></div>'}
document.querySelectorAll('select').forEach(x=>x.addEventListener('change',renderGames));renderGames();
let current=0,tab='summary';function picker(){document.querySelector('#matchPicker').innerHTML=officialMatches.map((m,i)=>`<button class="${i===current?'active':''}" data-i="${i}">${m.season} · ${esc(m.competition)}</button>`).join('');document.querySelectorAll('#matchPicker button').forEach(b=>b.onclick=()=>{current=+b.dataset.i;tab='summary';picker();matchCenter()})}
function matchCenter(){const m=officialMatches[current];let body=tab==='summary'?`<div class="verified-box"><b>✓ Επιβεβαιωμένο αποτέλεσμα</b><p>${esc(m.note)}</p></div>`:tab==='source'?`<div class="source-box"><p>Πηγή: επίσημη Τ.Ε. ΕΟΚ Λέσβου.</p><a href="${m.source}" target="_blank" rel="noopener">Άνοιγμα αρχικής ανακοίνωσης ↗</a></div>`:`<div class="empty-state"><b>${tab==='box'?'Box Score':'Ανά περίοδο'}</b><p>Δεν υπάρχουν επαρκή επίσημα δεδομένα για ασφαλή δημοσίευση. Η εφαρμογή δεν δημιουργεί υποθετικά στατιστικά.</p></div>`;document.querySelector('#matchCenter').innerHTML=`<div class="mc-score"><div class="mc-team">${esc(m.home)}</div><div class="mc-middle"><div class="meta">${m.date} · ${esc(m.competition)}</div><div class="big">${m.hs}<span>–</span>${m.as}</div><span class="status">ΤΕΛΙΚΟ</span></div><div class="mc-team">${esc(m.away)}</div></div><div class="mc-tabs">${[['summary','Σύνοψη'],['periods','Ανά περίοδο'],['box','Box Score'],['source','Πηγή']].map(([k,v])=>`<button class="${tab===k?'active':''}" data-tab="${k}">${v}</button>`).join('')}</div><div class="mc-body">${body}</div>`;document.querySelectorAll('.mc-tabs button').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;matchCenter()})}picker();matchCenter();
document.querySelector('#teamGrid').innerHTML=entities.map((x,i)=>`<article class="team"><div class="logo">${x==='Τ.Ε. Λέσβου'?'ΤΕ':'🏀'}</div><h3>${esc(x)}</h3><p>${x==='Τ.Ε. Λέσβου'?'Μικτή / Τοπική Επιτροπή':'Ιστορικό · Αγώνες · Σεζόν'}</p></article>`).join('');
document.querySelector('#tournamentCards').innerHTML=tournament.map(g=>`<article class="card mini"><div class="meta">${g[0]} · Κλειστό Νεάπολης</div><div class="match"><div class="team-name">${g[1]}</div><div class="vs">VS</div><div class="team-name">${g[2]}</div></div><a class="stream" href="${g[3]}" target="_blank" rel="noopener">▶ Επίσημο stream</a></article>`).join('');
function showSeason(i){const s=seasons[i];document.querySelector('#archiveDetail').innerHTML=`<div class="archive-title"><div><small>ΣΕΖΟΝ</small><h3>${s.season}</h3></div><span class="archive-status">${s.status}</span></div>${s.items.length?s.items.map(x=>`<article class="archive-item"><b>${x[0]}</b><p>${x[1]}</p><a href="${x[2]}" target="_blank" rel="noopener">✓ Επίσημη πηγή ↗</a></article>`).join(''):'<div class="empty-state"><b>Η χαρτογράφηση συνεχίζεται</b><p>Θα προστεθούν μόνο εγγραφές που μπορούν να τεκμηριωθούν.</p></div>'}`;document.querySelectorAll('.season-btn').forEach((b,n)=>b.classList.toggle('active',n===i))}
document.querySelector('#seasonGrid').innerHTML=seasons.map((s,i)=>`<button class="season-btn" data-i="${i}"><span>${s.season}</span><small>${s.status}</small><b>→</b></button>`).join('');document.querySelectorAll('.season-btn').forEach(b=>b.onclick=()=>showSeason(+b.dataset.i));showSeason(0);
document.querySelector('#historyList').innerHTML=`<article><time>2025–26</time><div><h3>Παλλεσβιακός · Κύπελλο Ανδρών</h3><p>Νίκη 67–62 επί της Αθλητικής Λέσχης Μυτιλήνης στον τελικό.</p></div></article><article><time>2025–26</time><div><h3>Ήφαιστος Λήμνου · Πρωτάθλημα Εφήβων</h3><p>Η επίσημη Τ.Ε. καταγράφει την κατάκτηση του τίτλου.</p></div></article><article><time>2025–26</time><div><h3>Αίολος Μυτιλήνης · Νεανίδων</h3><p>Νικήτρια ομάδα του τελικού της σεζόν.</p></div></article><article><time>2024–25</time><div><h3>Παλλεσβιακός · Πρωτάθλημα Ανδρών</h3><p>Κατέκτησε τον τίτλο με 85–76 επί του Παπάδου Γέρας.</p></div></article>`;
const menu=document.querySelector('#menuBtn'),nav=document.querySelector('#nav');menu.onclick=()=>nav.classList.toggle('open');nav.querySelectorAll('a').forEach(a=>a.onclick=()=>nav.classList.remove('open'));

// v7 Player Registry — only data explicitly published in official EOK match reports.
// No EOK player-profile URL is guessed from a name. It remains null until identity resolution is verified.
const playerRegistry=[
 {name:'Μισαηλίδης',team:'Παλλεσβιακός',season:'2025–26',competition:'Ειδικό Πρωτάθλημα Ανόδου NL2',games:1,points:28,threes:3,eokProfile:null,photo:null,source:'https://www.basket.gr/ellinika/eidhseis/eidiko-protathlima-anodoy-national-league-2-2/180984/',coverage:'Μερικό αρχείο · 1 verified αγώνας'},
 {name:'Μπουρούς',team:'Παλλεσβιακός',season:'2025–26',competition:'Ειδικό Πρωτάθλημα Ανόδου NL2',games:1,points:15,threes:0,eokProfile:null,photo:null,source:'https://www.basket.gr/ellinika/eidhseis/eidiko-protathlima-anodoy-national-league-2-2/180984/',coverage:'Μερικό αρχείο · 1 verified αγώνας'},
 {name:'Κομνηνός',team:'Παλλεσβιακός',season:'2025–26',competition:'Ειδικό Πρωτάθλημα Ανόδου NL2',games:1,points:12,threes:0,eokProfile:null,photo:null,source:'https://www.basket.gr/ellinika/eidhseis/eidiko-protathlima-anodoy-national-league-2-2/180984/',coverage:'Μερικό αρχείο · 1 verified αγώνας'},
 {name:'Αβραμίδης',team:'Αθλητική Λέσχη Μυτιλήνης',season:'2025–26',competition:'Πανελλήνιο Παίδων',games:1,points:20,threes:2,eokProfile:null,photo:null,source:'https://www.basket.gr/ellinika/eidhseis/panellinio-protathlima-paidon-ta-apot/178239/',coverage:'Μερικό αρχείο · 1 verified αγώνας'},
 {name:'Βουνάτσος',team:'Αθλητική Λέσχη Μυτιλήνης',season:'2025–26',competition:'Πανελλήνιο Παίδων',games:1,points:14,threes:0,eokProfile:null,photo:null,source:'https://www.basket.gr/ellinika/eidhseis/panellinio-protathlima-paidon-ta-apot/178239/',coverage:'Μερικό αρχείο · 1 verified αγώνας'},
 {name:'Σκοπελίτης',team:'Αθλητική Λέσχη Μυτιλήνης',season:'2025–26',competition:'Πανελλήνιο Παίδων',games:1,points:7,threes:0,eokProfile:null,photo:null,source:'https://www.basket.gr/ellinika/eidhseis/panellinio-protathlima-paidon-ta-apot/178239/',coverage:'Μερικό αρχείο · 1 verified αγώνας'}
];
function renderPlayers(){
 const q=(document.querySelector('#playerSearch')?.value||'').trim().toLocaleLowerCase('el');
 const tf=document.querySelector('#playerTeamFilter')?.value||'Όλες οι ομάδες';
 const rows=playerRegistry.filter(p=>(!q||(p.name+' '+p.team).toLocaleLowerCase('el').includes(q))&&(tf==='Όλες οι ομάδες'||p.team===tf));
 document.querySelector('#playerGrid').innerHTML=rows.map(p=>`<article class="player-card"><div class="player-head"><div class="avatar">🏀</div><div><h3>${esc(p.name)}</h3><p>${esc(p.team)} · ${esc(p.season)}</p></div></div><div class="source-badges"><span>✓ EOK MATCH DATA</span><span>IDENTITY REVIEW</span></div><p>${esc(p.competition)}</p><div class="statline"><div><b>${p.games}</b><small>verified αγ.</small></div><div><b>${p.points}</b><small>πόντοι</small></div><div><b>${p.threes}</b><small>3Π</small></div><div><b>—</b><small>career</small></div></div><div class="partial">${esc(p.coverage)} — δεν παρουσιάζεται ως πλήρες season total.</div><div class="player-actions"><a href="${p.source}" target="_blank" rel="noopener">Επίσημο φύλλο ΕΟΚ ↗</a>${p.eokProfile?`<a href="${p.eokProfile}" target="_blank" rel="noopener">Προφίλ ΕΟΚ ↗</a>`:'<span title="Απαιτείται ασφαλής ταυτοποίηση">Προφίλ ΕΟΚ: προς ταυτοποίηση</span>'}</div></article>`).join('')||'<div class="empty-panel"><h3>Δεν βρέθηκαν verified εγγραφές.</h3></div>';
}
document.querySelector('#playerSearch')?.addEventListener('input',renderPlayers);
document.querySelector('#playerTeamFilter')?.addEventListener('change',renderPlayers);
renderPlayers();

// v8 — Verification Center. Conservative by design: no automatic identity approval.
const verificationQueue = playerRegistry.map((p,i)=>({
 id:`player-${i+1}`, player:p.name, team:p.team, season:p.season,
 evidence:[`Επίσημο EOK match report`, `${p.team} · ${p.season}`],
 status:'review_required', reason:'Δεν έχει επιβεβαιωθεί μοναδικό EOK profile URL.'
}));
const verificationState={lastAudit:null};
function normalizeGreekName(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleUpperCase('el-GR').replace(/[^Α-ΩA-Z0-9 ]/g,' ').replace(/\s+/g,' ').trim()}
function identityProposal(candidate, registryEntry){
 const exact=normalizeGreekName(candidate.fullName)===normalizeGreekName(registryEntry.fullName);
 const team=!!candidate.team&&!!registryEntry.team&&normalizeGreekName(candidate.team)===normalizeGreekName(registryEntry.team);
 const season=!!candidate.season&&candidate.season===registryEntry.season;
 return {exactName:exact,teamMatch:team,seasonMatch:season,canAutoVerify:false,status:(exact&&team&&season)?'review_required':'conflict'};
}
function runIntegrityAudit(){
 const errors=[], warnings=[];
 officialMatches.forEach(m=>{if(!m.source)errors.push(`${m.id}: missing source`);if(!Number.isInteger(m.hs)||!Number.isInteger(m.as)||m.hs<0||m.as<0)errors.push(`${m.id}: invalid score`);});
 playerRegistry.forEach(p=>{if(!p.source)errors.push(`${p.name}: missing source`);if(p.eokProfile)errors.push(`${p.name}: EOK profile URL exists without verified identity state`);if(!String(p.coverage).toLowerCase().includes('μερικό'))warnings.push(`${p.name}: coverage label must remain explicit`);});
 const duplicateGames=new Set(); officialMatches.forEach(m=>{const k=[m.date,normalizeGreekName(m.home),normalizeGreekName(m.away)].join('|');if(duplicateGames.has(k))errors.push(`${m.id}: duplicate game`);duplicateGames.add(k)});
 verificationState.lastAudit={errors,warnings,at:new Date().toISOString()};return verificationState.lastAudit;
}
function renderVerification(){
 const verifiedGames=officialMatches.filter(m=>m.source&&Number.isInteger(m.hs)&&Number.isInteger(m.as)).length;
 const pending=verificationQueue.filter(x=>x.status==='review_required').length;
 const conflicts=verificationQueue.filter(x=>x.status==='conflict').length;
 document.querySelector('#healthGrid').innerHTML=[['Verified games',verifiedGames],['Identity reviews',pending],['Conflicts',conflicts],['Unsafe profile links',playerRegistry.filter(p=>p.eokProfile).length]].map(x=>`<article><b>${x[1]}</b><span>${x[0]}</span></article>`).join('');
 document.querySelector('#reviewQueue').innerHTML=verificationQueue.map(q=>`<article class="review-card"><div><span class="review-status ${q.status}">${q.status.replace('_',' ').toUpperCase()}</span><h4>${esc(q.player)}</h4><p>${esc(q.team)} · ${esc(q.season)}</p><small>${esc(q.reason)}</small></div><div class="evidence">${q.evidence.map(e=>`<span>✓ ${esc(e)}</span>`).join('')}</div><div class="review-actions"><button data-action="hold" data-id="${q.id}">Hold</button><button data-action="reject" data-id="${q.id}">Reject</button></div></article>`).join('');
 document.querySelector('#publishGates').innerHTML=`<div class="gate ok">✓ Verified game must have official source</div><div class="gate ok">✓ Non-negative integer final scores</div><div class="gate ok">✓ Partial stats labelled as partial</div><div class="gate blocked">⛔ No automatic player identity linking</div><div class="gate blocked">⛔ No uncleared player photos</div>`;
 document.querySelectorAll('.review-actions button').forEach(b=>b.onclick=()=>{const q=verificationQueue.find(x=>x.id===b.dataset.id);q.status=b.dataset.action==='reject'?'rejected':'review_required';q.reason=b.dataset.action==='reject'?'Απορρίφθηκε το υποψήφιο identity match.':'Παραμένει σε χειροκίνητο έλεγχο.';renderVerification()});
}
renderVerification();
document.querySelector('#runAudit').onclick=()=>{const r=runIntegrityAudit();document.querySelector('#auditResult').innerHTML=r.errors.length?`<b>BLOCKED</b><br>${r.errors.map(esc).join('<br>')}`:`<b>PASS</b> · 0 critical errors${r.warnings.length?` · ${r.warnings.length} warnings`:''}`;};

// v9 — immutable provenance + conflict engine + release gate.
const sourcePriority={official_final_recap:100,official_result_text:90,official_schedule:70,official_image:50};
const provenanceLedger=[
 {entity:'men-2425',field:'final_score',value:'76-85',source:'https://lesvosbasket.gr/apotelesma-agona-07-04-25/',kind:'official_result_text',published:'2025-04-08',status:'verified'},
 {entity:'cup-2526',field:'final_score',value:'62-67',source:'https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-18-19-10-25/',kind:'official_result_text',published:'2025-10-20',status:'verified'},
 {entity:'youth-2526',field:'champion',value:'Α.Ο. Ήφαιστος Λήμνου',source:'https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-28-02-01-03-26/',kind:'official_result_text',published:'2026-03-02',status:'verified'},
 {entity:'youngwomen-2526',field:'winner',value:'Ε.Γ.Σ. Αίολος Μυτιλήνης',source:'https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-31-01-01-02-26/',kind:'official_result_text',published:'2026-02-02',status:'verified'}
];
function resolveEvidence(rows){
 const verified=rows.filter(x=>x.status==='verified');
 const values=[...new Set(verified.map(x=>normalizeGreekName(x.value)))];
 if(values.length>1)return {status:'source_conflict',publish:false,reason:'Διαφορετικές verified επίσημες τιμές.'};
 const best=[...verified].sort((a,b)=>(sourcePriority[b.kind]||0)-(sourcePriority[a.kind]||0)||String(b.published).localeCompare(String(a.published)))[0];
 return best?{status:'verified',publish:true,best}:{status:'review_required',publish:false,reason:'Δεν υπάρχει verified evidence.'};
}
function releaseGate(){
 const audit=runIntegrityAudit();
 const conflicts=[];
 const groups={}; provenanceLedger.forEach(x=>{const k=x.entity+'|'+x.field;(groups[k]??=[]).push(x)});
 Object.entries(groups).forEach(([k,v])=>{const r=resolveEvidence(v);if(r.status==='source_conflict')conflicts.push(k)});
 const unresolved=verificationQueue.filter(x=>x.status==='conflict').length;
 return {release:!audit.errors.length&&!conflicts.length&&!unresolved,critical:audit.errors.length,conflicts:conflicts.length,identityConflicts:unresolved};
}
function renderProvenance(){
 const host=document.querySelector('#provenanceLedger'); if(!host)return;
 host.innerHTML=provenanceLedger.map(x=>`<article class="ledger-row"><div><b>${esc(x.entity)}</b><small>${esc(x.field)} · ${esc(x.published)}</small></div><span class="verified">✓ ${esc(x.status.toUpperCase())}</span><div>${esc(x.value)}</div><a href="${x.source}" target="_blank" rel="noopener">Πηγή ↗</a></article>`).join('');
 const g=releaseGate(), box=document.querySelector('#releaseGate');
 box.className='release-gate '+(g.release?'ok':'blocked');box.innerHTML=`<b>${g.release?'✓ RELEASE GATE: PASS':'⛔ RELEASE GATE: BLOCKED'}</b><span>${g.critical} critical · ${g.conflicts} source conflicts · ${g.identityConflicts} identity conflicts</span>`;
}
renderProvenance();

// v10 — verified dataset expansion + standings adjustments + integrity evidence.
const verifiedExpandedGames=[
 {id:'boys-240224',season:'2023–24',competition:'Πρωτάθλημα Παίδων',date:'24/02/2024',home:'Α.Ο. Ήφαιστος Λήμνου',away:'Ε.Γ.Σ. Αίολος Μυτιλήνης',hs:60,as:56,periods:[[16,10],[14,13],[12,18],[18,15]],source:'https://lesvosbasket.gr/apotelesmata-agonon-24-25-02-24/',sourceKind:'official_result_text',verification:'verified'},
 {id:'nl2-170626',season:'2025–26',competition:'Ειδικό Πρωτάθλημα Ανόδου NL2',date:'17/06/2026',home:'Ίωνες ΑΟ Χίου',away:'Παλλεσβιακός',hs:96,as:78,periods:[[32,27],[18,21],[26,17],[20,13]],source:'https://www.basket.gr/ellinika/eidhseis/eidiko-protathlima-anodoy-national-league-2-2/180984/',sourceKind:'official_final_recap',verification:'verified'}
];
officialMatches.push(...verifiedExpandedGames.map(g=>({...g,note:'Επιβεβαιωμένο από επίσημη δημοσίευση με αναλυτικό σκορ.'})));
provenanceLedger.push(
 {entity:'boys-240224',field:'final_score',value:'60-56',source:verifiedExpandedGames[0].source,kind:'official_result_text',published:'2024-02-27',status:'verified'},
 {entity:'boys-240224',field:'periods',value:'16-10|14-13|12-18|18-15',source:verifiedExpandedGames[0].source,kind:'official_result_text',published:'2024-02-27',status:'verified'},
 {entity:'nl2-170626',field:'final_score',value:'96-78',source:verifiedExpandedGames[1].source,kind:'official_final_recap',published:'2026-06-21',status:'verified'},
 {entity:'nl2-170626',field:'periods',value:'32-27|18-21|26-17|20-13',source:verifiedExpandedGames[1].source,kind:'official_final_recap',published:'2026-06-21',status:'verified'}
);
const standingsAdjustments=[{season:'2023–24',competition:'Πρωτάθλημα Ανδρών',team:'Πολυνίκης',type:'μηδενισμός',count:1,status:'verified',source:'https://lesvosbasket.gr/vathmologies-protathlimaton-t-e-e-o-k-lesvou-2023-2024-15/',note:'Η επίσημη ανακοίνωση αναφέρει ρητά: «Ο Πολυνίκης έχει ένα μηδενισμό». Δεν ανακατασκευάζουμε τον πίνακα από εικόνα χωρίς χειροκίνητη επαλήθευση.'}];
function periodAudit(g){if(!g.periods)return {status:'not_available'};const h=g.periods.reduce((s,p)=>s+p[0],0),a=g.periods.reduce((s,p)=>s+p[1],0);return {status:h===g.hs&&a===g.as?'pass':'fail',calculated:[h,a]}}
function renderV10Standings(){const host=document.querySelector('#standings');if(!host)return;const old=host.querySelector('.empty-panel');if(old)old.outerHTML=`<div class="standings-v10"><div class="trust-note">✓ Διοικητικές προσαρμογές αποθηκεύονται χωριστά από τους αγωνιστικούς υπολογισμούς. Δεν ανακατασκευάζουμε πίνακες που υπάρχουν μόνο ως εικόνα.</div>${standingsAdjustments.map(a=>`<article class="adjustment-card"><div><span class="verified">✓ VERIFIED ADJUSTMENT</span><h3>${esc(a.team)} · ${esc(a.type)}</h3><p>${esc(a.season)} · ${esc(a.competition)}</p><small>${esc(a.note)}</small></div><a href="${a.source}" target="_blank" rel="noopener">Επίσημη πηγή ↗</a></article>`).join('')}</div>`}
function renderIntegrityEvidence(){const target=document.querySelector('#provenance');if(!target)return;let el=document.querySelector('#integrityEvidence');if(!el){el=document.createElement('div');el.id='integrityEvidence';el.className='integrity-evidence';target.appendChild(el)}const rows=verifiedExpandedGames.map(g=>({g,a:periodAudit(g)}));el.innerHTML=`<h3>Arithmetic verification</h3><p class="section-intro">Για αγώνες με δημοσιευμένα δεκάλεπτα, το άθροισμα ελέγχεται απέναντι στο τελικό σκορ.</p>${rows.map(({g,a})=>`<article class="ledger-row"><div><b>${esc(g.home)} – ${esc(g.away)}</b><small>${esc(g.date)} · ${esc(g.competition)}</small></div><span class="verified">${a.status==='pass'?'✓ PASS':'⛔ FAIL'}</span><div>${g.periods.map(p=>p.join('–')).join(' · ')} → ${a.calculated.join('–')}</div><a href="${g.source}" target="_blank" rel="noopener">Πηγή ↗</a></article>`).join('')}`}
renderGames();picker();matchCenter();renderV10Standings();renderIntegrityEvidence();renderProvenance();

// v13 — expanded official dataset and cross-source verification badges.
const v13Games=[
 {id:'eok-u16-2026-alm-kolossos',season:'2025–26',competition:'Πανελλήνιο Παίδων — Β\' Φάση',date:'15/05/2026',home:'Αθλητική Λέσχη Μυτιλήνης',away:'ΑΟ Κολοσσός',hs:48,as:76,periods:[[15,18],[11,19],[15,22],[7,17]],source:'https://www.basket.gr/ellinika/eidhseis/panellinio-protathlima-paidon-ta-apot/178239/',verification:'verified'},
 {id:'te-cup-2025-final-v13',season:'2025–26',competition:'Κύπελλο Ανδρών Γ. Καρέκος',date:'19/10/2025',home:'Αθλητική Λέσχη Μυτιλήνης',away:'Παλλεσβιακός ΠΓ',hs:62,as:67,source:'https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-18-19-10-25/',verification:'verified'}
];
for(const g of v13Games){if(!officialMatches.some(x=>x.id===g.id))officialMatches.push(g)}
function renderV13Quality(){const host=document.querySelector('#v13-quality');if(!host)return;host.innerHTML=`<div class="section-head"><div><small>V13 · CROSS-SOURCE QUALITY</small><h2>Επέκταση verified dataset</h2></div></div><div class="trust-note">✓ Ο τίτλος Εφήβων 2025–26 του ΑΟ Ήφαιστος Λήμνου επιβεβαιώνεται ανεξάρτητα τόσο από την Τ.Ε. ΕΟΚ Λέσβου όσο και από την ΕΟΚ.</div><div class="cards compact"><article class="game-card"><span class="verified">✓ VERIFIED · EOK</span><h3>Αθλητική Λέσχη Μυτιλήνης <b>48–76</b> ΑΟ Κολοσσός</h3><p>15/05/2026 · Πανελλήνιο Παίδων — Β' Φάση</p><small>Δεκάλεπτα 15–18 · 11–19 · 15–22 · 7–17 · arithmetic PASS</small><a href="${v13Games[0].source}" target="_blank" rel="noopener">Επίσημη πηγή ↗</a></article><article class="game-card"><span class="verified">✓ VERIFIED · ΤΕ ΛΕΣΒΟΥ</span><h3>Αθλητική Λέσχη Μυτιλήνης <b>62–67</b> Παλλεσβιακός ΠΓ</h3><p>19/10/2025 · Τελικός Κυπέλλου Ανδρών «Γ. Καρέκος»</p><small>Το κείμενο της επίσημης ανακοίνωσης αναφέρει ρητά νικητή και τελικό σκορ.</small><a href="${v13Games[1].source}" target="_blank" rel="noopener">Επίσημη πηγή ↗</a></article></div>`}
renderGames();renderV13Quality();

// v15 — team profiles built only from verified public-layer records.
const teamTitles=[
 {team:'Παλλεσβιακός',season:'2024–25',title:'Πρωταθλητής Ανδρών Τ.Ε. Λέσβου',source:'https://lesvosbasket.gr/apotelesma-agona-07-04-25/'},
 {team:'Παλλεσβιακός',season:'2025–26',title:'Κυπελλούχος Ανδρών «Γ. Καρέκος»',source:'https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-18-19-10-25/'},
 {team:'Α.Ο. Ήφαιστος Λήμνου',season:'2025–26',title:'Πρωταθλητής Εφήβων Τ.Ε. Λέσβου',source:'https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-28-02-01-03-26/'},
 {team:'Ε.Γ.Σ. Αίολος Μυτιλήνης',season:'2025–26',title:'Νικήτρια Νεανίδων Τ.Ε. Λέσβου',source:'https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-31-01-01-02-26/'}
];
const teamAliases={
 'Παλλεσβιακός':['ΠΑΛΛΕΣΒΙΑΚΟΣ','ΠΑΛΛΕΣΒΙΑΚΟΣ ΠΓ','ΕΠΓΣ ΠΑΛΛΕΣΒΙΑΚΟΣ'],
 'Αθλητική Λέσχη Μυτιλήνης':['ΑΘΛΗΤΙΚΗ ΛΕΣΧΗ ΜΥΤΙΛΗΝΗΣ','ΑΘΛΗΤΙΚΗ ΛΕΣΧΗ ΜΥΤΙΛΗΣ'],
 'Α.Ο. Ήφαιστος Λήμνου':['Α Ο ΗΦΑΙΣΤΟΣ ΛΗΜΝΟΥ','ΑΟ ΗΦΑΙΣΤΟΣ ΛΗΜΝΟΥ','ΗΦΑΙΣΤΟΣ ΛΗΜΝΟΥ','ΗΦΑΙΣΤΟΣ'],
 'Ε.Γ.Σ. Αίολος Μυτιλήνης':['Ε Γ Σ ΑΙΟΛΟΣ ΜΥΤΙΛΗΝΗΣ','ΑΙΟΛΟΣ ΜΥΤΙΛΗΝΗΣ','ΑΙΟΛΟΣ'],
 'Α.Π.Σ. Παπάδος Γέρας':['Α Π Σ ΠΑΠΑΔΟΣ ΓΕΡΑΣ','ΠΑΠΑΔΟΣ ΓΕΡΑΣ']
};
function canonicalTeam(v){const n=normalizeGreekName(v);for(const [canonical,aliases] of Object.entries(teamAliases)){if(normalizeGreekName(canonical)===n||aliases.some(a=>normalizeGreekName(a)===n))return canonical}return v}
function buildTeamProfiles(){
 const names=new Set(); officialMatches.forEach(g=>{names.add(canonicalTeam(g.home));names.add(canonicalTeam(g.away))}); teamTitles.forEach(t=>names.add(t.team)); playerRegistry.forEach(p=>names.add(canonicalTeam(p.team)));
 return [...names].filter(Boolean).map(name=>{
  const games=officialMatches.filter(g=>canonicalTeam(g.home)===name||canonicalTeam(g.away)===name).filter(g=>g.source&&Number.isInteger(g.hs)&&Number.isInteger(g.as));
  const titles=teamTitles.filter(t=>t.team===name); const players=playerRegistry.filter(p=>canonicalTeam(p.team)===name);
  const wins=games.filter(g=>(canonicalTeam(g.home)===name&&g.hs>g.as)||(canonicalTeam(g.away)===name&&g.as>g.hs)).length;
  const sources=new Set([...games.map(g=>g.source),...titles.map(t=>t.source),...players.map(p=>p.source)]);
  return {name,games,titles,players,wins,sources:[...sources],coverage:'PARTIAL'};
 }).sort((a,b)=>b.games.length-a.games.length||a.name.localeCompare(b.name,'el'));
}
let activeTeam=null;
function renderTeamProfiles(){
 const profiles=buildTeamProfiles(),host=document.querySelector('#teamGrid'); if(!host)return;
 host.innerHTML=profiles.map(p=>`<button class="team team-profile-card" data-team="${esc(p.name)}"><div class="logo">🏀</div><h3>${esc(p.name)}</h3><p>${p.games.length} verified αγ. · ${p.titles.length} verified τίτλοι</p><span class="badge warn">${p.coverage}</span></button>`).join('');
 host.querySelectorAll('[data-team]').forEach(b=>b.onclick=()=>{activeTeam=b.dataset.team;renderTeamDetail();document.querySelector('#teamDetail')?.scrollIntoView({behavior:'smooth',block:'center'})});
 renderTeamDetail();
}
function renderTeamDetail(){
 const host=document.querySelector('#teamDetail');if(!host)return;const profiles=buildTeamProfiles();const p=profiles.find(x=>x.name===activeTeam)||profiles[0];if(!p){host.innerHTML='';return}activeTeam=p.name;
 const games=p.games.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 host.innerHTML=`<div class="team-detail-head"><div><small>VERIFIED TEAM PROFILE · ${p.coverage}</small><h3>${esc(p.name)}</h3><p>Η κάλυψη αφορά μόνο εγγραφές που έχουν ήδη περάσει στο verified public layer· δεν αποτελεί πλήρες ιστορικό συλλόγου.</p></div><div class="team-kpis"><span><b>${p.games.length}</b>αγώνες</span><span><b>${p.wins}</b>νίκες*</span><span><b>${p.titles.length}</b>τίτλοι</span><span><b>${p.sources.length}</b>πηγές</span></div></div><small>* Μετρά μόνο τους verified αγώνες που υπάρχουν στο τρέχον dataset.</small>
 <div class="team-detail-grid"><div><h4>Verified αγώνες</h4>${games.length?games.map(g=>`<article class="archive-item"><b>${esc(g.home)} ${g.hs}–${g.as} ${esc(g.away)}</b><p>${esc(g.season)} · ${esc(g.competition)} · ${esc(g.date)}</p><a href="${g.source}" target="_blank" rel="noopener">Επίσημη πηγή ↗</a></article>`).join(''):'<p>Δεν υπάρχουν ακόμη verified αγώνες.</p>'}</div><div><h4>Τίτλοι / διακρίσεις</h4>${p.titles.length?p.titles.map(t=>`<article class="archive-item"><b>${esc(t.season)} · ${esc(t.title)}</b><a href="${t.source}" target="_blank" rel="noopener">Επίσημη πηγή ↗</a></article>`).join(''):'<p>Δεν έχει καταχωριστεί verified τίτλος.</p>'}<h4>Παίκτες στο verified dataset</h4>${p.players.length?p.players.map(x=>`<p><b>${esc(x.name)}</b> · ${esc(x.coverage)}</p>`).join(''):'<p>Δεν υπάρχουν ακόμη ασφαλείς player entries.</p>'}</div></div>`;
}
renderTeamProfiles();

// v16 — richer verified Match Center + season views. Fail-closed by design.
const v16Games=[
 {id:'eok-u18-2026-ifaistos-vrontados',season:'2025–26',competition:'Πανελλήνιο Εφήβων — Β\' Φάση',date:'05/04/2026',home:'Α.Ο. Ήφαιστος Λήμνου',away:'ΦΟ Βροντάδου',hs:62,as:60,periods:[[20,10],[9,15],[14,9],[14,23],[5,3]],periodMode:'quarter_points_plus_ot',note:'Ο Ήφαιστος επικράτησε στην παράταση. Η επίσημη ΕΟΚ δημοσιεύει τελικό σκορ, δεκάλεπτα και παράταση.',source:'https://www.basket.gr/slider/panellinio-efivon-ta-apotelesmata-to-3/173728/',sourceOrg:'ΕΟΚ',verification:'verified'},
 {id:'te-u16-2024-ifaistos-aiolos',season:'2023–24',competition:'Παίδων Τ.Ε. ΕΟΚ Λέσβου',date:'24/02/2024',home:'Α.Ο. Ήφαιστος Λήμνου',away:'Ε.Γ.Σ. Αίολος Μυτιλήνης',hs:60,as:56,periods:[[16,10],[14,13],[12,18],[18,15]],periodMode:'quarter_points',note:'Επίσημο αποτέλεσμα Τ.Ε. Λέσβου με πλήρη δεκάλεπτα.',source:'https://lesvosbasket.gr/apotelesmata-agonon-24-25-02-24/',sourceOrg:'Τ.Ε. ΕΟΚ Λέσβου',verification:'verified'}
];
for(const g of v16Games){if(!officialMatches.some(x=>x.id===g.id))officialMatches.push(g)}
function periodAudit(m){if(!m.periods?.length)return null;const h=m.periods.reduce((s,p)=>s+p[0],0),a=m.periods.reduce((s,p)=>s+p[1],0);return {home:h,away:a,pass:h===m.hs&&a===m.as}}
function sourceOrg(m){return m.sourceOrg||(m.source.includes('basket.gr')?'ΕΟΚ':'Τ.Ε. ΕΟΚ Λέσβου')}
function matchCenter(){const m=officialMatches[current]||officialMatches[0];if(!m)return;const audit=periodAudit(m);let body='';
 if(tab==='summary')body=`<div class="verified-box"><b>✓ Επιβεβαιωμένο αποτέλεσμα</b><p>${esc(m.note||'Το αποτέλεσμα προέρχεται από επίσημη πηγή.')}</p>${audit?`<small>Arithmetic audit: <b>${audit.pass?'PASS':'BLOCKED'}</b></small>`:''}</div>`;
 else if(tab==='periods')body=m.periods?.length?`<div class="period-grid">${m.periods.map((p,i)=>`<div><small>${i<4?`${i+1}ο δεκ.`:`ΠΑΡ. ${i-3}`}</small><b>${p[0]}–${p[1]}</b></div>`).join('')}</div><div class="trust-note">${audit?.pass?'✓ Τα επιμέρους σκορ αθροίζονται ακριβώς στο τελικό αποτέλεσμα.':'⛔ Αποτυχία arithmetic validation — δεν πρέπει να δημοσιευτεί.'}</div>`:`<div class="empty-state"><b>Ανά περίοδο</b><p>Δεν υπάρχουν επαρκή επίσημα δεδομένα για ασφαλή δημοσίευση.</p></div>`;
 else if(tab==='box')body=`<div class="empty-state"><b>Box Score</b><p>${m.boxScore?'Υπάρχουν source-backed στοιχεία, αλλά η προβολή απαιτεί πλήρη validation.':'Δεν υπάρχει πλήρες επίσημο box score στο verified public layer για αυτόν τον αγώνα.'}</p></div>`;
 else body=`<div class="source-box"><p><b>${esc(sourceOrg(m))}</b> · official source</p><p>Verification: <b>${esc((m.verification||'verified').toUpperCase())}</b></p><a href="${m.source}" target="_blank" rel="noopener">Άνοιγμα αρχικής ανακοίνωσης ↗</a></div>`;
 document.querySelector('#matchCenter').innerHTML=`<div class="mc-score"><div class="mc-team">${esc(m.home)}</div><div class="mc-middle"><div class="meta">${esc(m.date)} · ${esc(m.competition)}</div><div class="big">${m.hs}<span>–</span>${m.as}</div><span class="status">ΤΕΛΙΚΟ</span></div><div class="mc-team">${esc(m.away)}</div></div><div class="mc-tabs">${[['summary','Σύνοψη'],['periods','Ανά περίοδο'],['box','Box Score'],['source','Πηγή']].map(([k,v])=>`<button class="${tab===k?'active':''}" data-tab="${k}">${v}</button>`).join('')}</div><div class="mc-body">${body}</div>`;document.querySelectorAll('.mc-tabs button').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;matchCenter()})}
function renderSeasonViews(){const host=document.querySelector('#teamSeasonView');if(!host)return;const profiles=buildTeamProfiles();host.innerHTML=profiles.slice(0,6).map(p=>{const by={};p.games.forEach(g=>(by[g.season]??=[]).push(g));return `<article class="season-team-card"><h3>${esc(p.name)}</h3>${Object.entries(by).sort().reverse().map(([s,gs])=>`<div class="season-row"><b>${esc(s)}</b><span>${gs.length} verified αγ.</span><small>PARTIAL</small></div>`).join('')||'<p>Χωρίς verified season games.</p>'}</article>`}).join('')}
function runV16Audit(){const errors=[];const ids=new Set();for(const m of officialMatches){if(ids.has(m.id))errors.push(`duplicate:${m.id}`);ids.add(m.id);if(!m.source||!/^https:\/\/(www\.)?(basket\.gr|lesvosbasket\.gr)\//.test(m.source))errors.push(`source:${m.id}`);if(!Number.isInteger(m.hs)||!Number.isInteger(m.as)||m.hs<0||m.as<0)errors.push(`score:${m.id}`);const a=periodAudit(m);if(a&&!a.pass)errors.push(`periods:${m.id}`)}return {pass:errors.length===0,errors}}
renderGames();picker();matchCenter();renderTeamProfiles();renderSeasonViews();

// v17 — source inbox + freshness guard. New official posts never become verified numeric data automatically.
const sourceInbox=[
 {id:'te-2026-09-14-result',published:'14/09/2026',eventDate:'12/09/2026',title:'ΑΠΟΤΕΛΕΣΜΑ ΑΓΩΝΑ 12/09/26',source:'https://lesvosbasket.gr/apotelesma-agona-12-09-26/',org:'Τ.Ε. ΕΟΚ Λέσβου',contentMode:'image_only_numeric',status:'review_required',reason:'Η επίσημη ανάρτηση είναι διαθέσιμη, αλλά το ανακτήσιμο κείμενο δεν τεκμηριώνει με ασφάλεια το σκορ.'},
 {id:'te-2026-03-02-u18-title',published:'02/03/2026',eventDate:'28/02/2026',title:'Ολοκλήρωση Πρωταθλήματος Εφήβων 2025–26',source:'https://lesvosbasket.gr/apotelesmata-vathmologies-agonon-28-02-01-03-26/',org:'Τ.Ε. ΕΟΚ Λέσβου',contentMode:'text_claim',status:'verified',reason:'Το κείμενο αναφέρει ρητά τον ΑΟ Ήφαιστο Λήμνου ως πρωταθλητή.'},
 {id:'eok-2026-u18-program',published:'2026',eventDate:'03–05/04/2026',title:'Πανελλήνιο Εφήβων — Αγώνες Βορείου Αιγαίου',source:'https://www.basket.gr/ellinika/eidhseis/panellinio-protathlima-efivon-to-prog/173507/',org:'ΕΟΚ',contentMode:'text_schedule',status:'verified',reason:'Η ΕΟΚ κατονομάζει τον Ήφαιστο ως πρωταθλητή Τ.Ε. Λέσβου και δημοσιεύει το πρόγραμμα.'},
 {id:'eok-2026-nl2-pallesviakos',published:'21/06/2026',eventDate:'17/06/2026',title:'Ίωνες–Παλλεσβιακός 96–78',source:'https://www.basket.gr/ellinika/eidhseis/eidiko-protathlima-anodoy-national-league-2-2/180984/',org:'ΕΟΚ',contentMode:'text_result_box',status:'verified',reason:'Τελικό σκορ, δεκάλεπτα και σκόρερ δημοσιεύονται σε επίσημο κείμενο.'}
];
function freshnessClass(x){return x.status==='verified'?'verified':'badge warn'}
function renderSourceInbox(){const host=document.querySelector('#sourceInbox');if(!host)return;host.innerHTML=sourceInbox.map(x=>`<article class="archive-item source-inbox-row"><div><span class="${freshnessClass(x)}">${x.status==='verified'?'✓ VERIFIED':'⚠ REVIEW REQUIRED'}</span><h3>${esc(x.title)}</h3><p>${esc(x.org)} · δημοσίευση ${esc(x.published)} · γεγονός ${esc(x.eventDate)}</p><small>${esc(x.reason)}</small></div><a href="${x.source}" target="_blank" rel="noopener">Επίσημη πηγή ↗</a></article>`).join('')}
function runV17Audit(){const base=runV16Audit();const errors=[...base.errors],warnings=[];const ids=new Set();for(const x of sourceInbox){if(ids.has(x.id))errors.push(`inbox-duplicate:${x.id}`);ids.add(x.id);if(!/^https:\/\/(www\.)?(basket\.gr|lesvosbasket\.gr)\//.test(x.source))errors.push(`inbox-source:${x.id}`);if(x.contentMode==='image_only_numeric'&&x.status==='verified')errors.push(`unsafe-image-promotion:${x.id}`);if(x.status==='review_required')warnings.push(`review:${x.id}`)}return {pass:errors.length===0,errors,warnings}}
function renderV17Gate(){const host=document.querySelector('#v17Gate');if(!host)return;const a=runV17Audit();host.innerHTML=`<div class="${a.pass?'verified-box':'audit-result bad'}"><b>${a.pass?'✓ RELEASE SAFETY PASS':'⛔ RELEASE BLOCKED'}</b><p>${a.errors.length} critical errors · ${a.warnings.length} review items</p><small>Review items παραμένουν εκτός verified numeric layer μέχρι χειροκίνητη επιβεβαίωση.</small></div>`}
renderSourceInbox();renderV17Gate();

// v18 — production readiness: canonical event ledger + strict publication policy.
const v18Ledger = officialMatches.map(m => ({
  eventId:m.id, season:m.season, competition:m.competition, eventDate:m.date,
  home:canonicalTeam(m.home), away:canonicalTeam(m.away), homeScore:m.hs, awayScore:m.as,
  verification:m.verification||'verified', source:m.source, sourceOrg:sourceOrg(m),
  arithmetic:periodAudit(m)?.pass ?? null, coverage:'partial'
}));
function runV18Audit(){
 const prior=runV17Audit(), errors=[...prior.errors], warnings=[...prior.warnings];
 const keySet=new Set();
 for(const x of v18Ledger){
   const key=[x.season,x.competition,x.eventDate,x.home,x.away].map(normalizeGreekName).join('|');
   if(keySet.has(key)) errors.push(`semantic-duplicate:${x.eventId}`); keySet.add(key);
   if(x.verification==='verified' && !x.source) errors.push(`verified-without-source:${x.eventId}`);
   if(x.arithmetic===false) errors.push(`arithmetic:${x.eventId}`);
   if(x.coverage!=='partial' && x.coverage!=='complete') errors.push(`coverage:${x.eventId}`);
 }
 for(const x of sourceInbox){
   if(x.status!=='verified' && v18Ledger.some(e=>e.source===x.source)) errors.push(`unreviewed-promoted:${x.id}`);
 }
 return {pass:errors.length===0,errors,warnings};
}
function renderProductionHealth(){
 const host=document.querySelector('#productionHealth'); if(!host)return;
 const a=runV18Audit(), verified=v18Ledger.filter(x=>x.verification==='verified').length;
 host.innerHTML=`<div class="section-head"><div><small>PRODUCTION READINESS</small><h2>Data Safety Gate</h2></div></div><div class="${a.pass?'verified-box':'audit-result bad'}"><b>${a.pass?'✓ SAFE DATA BUILD':'⛔ BUILD BLOCKED'}</b><p>${verified} verified events · ${a.errors.length} critical errors · ${a.warnings.length} review items</p><small>Το gate ελέγχει provenance, semantic duplicates, arithmetic consistency και απαγορεύει promotion από review queue.</small></div>`;
}
renderProductionHealth();

// v19 — evidence maturity + official-source monitoring. No review-only numeric claim is promoted.
const evidenceMaturity = {
  'text_result_box': {rank:5,label:'OFFICIAL TEXT + BOX'},
  'text_result': {rank:4,label:'OFFICIAL TEXT RESULT'},
  'text_claim': {rank:3,label:'OFFICIAL TEXT CLAIM'},
  'text_schedule': {rank:2,label:'OFFICIAL SCHEDULE'},
  'image_only_numeric': {rank:1,label:'IMAGE — REVIEW'}
};
function classifyEvidence(source){
  const inbox=sourceInbox.find(x=>x.source===source);
  if(inbox) return evidenceMaturity[inbox.contentMode]||{rank:0,label:'UNCLASSIFIED'};
  return {rank:3,label:'OFFICIAL VERIFIED SOURCE'};
}
function runV19Audit(){
  const prior=runV18Audit(), errors=[...prior.errors], warnings=[...prior.warnings];
  for(const e of v18Ledger){
    const maturity=classifyEvidence(e.source);
    if(e.verification==='verified' && maturity.rank<2) errors.push(`weak-evidence:${e.eventId}`);
    if(e.home===e.away) errors.push(`same-team:${e.eventId}`);
    if(e.homeScore===null||e.awayScore===null) errors.push(`missing-score:${e.eventId}`);
  }
  const latest=sourceInbox.find(x=>x.id==='te-2026-09-14-result');
  if(latest?.status!=='review_required') errors.push('latest-image-result-must-remain-review');
  return {pass:errors.length===0,errors,warnings};
}
function renderEvidenceMaturity(){
 const host=document.querySelector('#evidenceMaturity'); if(!host)return;
 const a=runV19Audit();
 const rows=sourceInbox.map(x=>{const e=evidenceMaturity[x.contentMode]||{rank:0,label:'UNCLASSIFIED'};return `<article class="archive-item"><div><b>${esc(x.title)}</b><p>${esc(x.org)} · ${esc(e.label)}</p><small>${esc(x.reason)}</small></div><span class="${x.status==='verified'?'verified':'badge warn'}">${x.status==='verified'?'✓ VERIFIED':'⚠ REVIEW'}</span></article>`}).join('');
 host.innerHTML=`<div class="section-head"><div><small>V19 · EVIDENCE CONTROL</small><h2>Ωριμότητα τεκμηρίωσης</h2></div></div><div class="${a.pass?'verified-box':'audit-result bad'}"><b>${a.pass?'✓ EVIDENCE GATE PASS':'⛔ EVIDENCE GATE BLOCKED'}</b><p>${a.errors.length} critical errors · ${a.warnings.length} review items</p><small>Image-only αριθμητικά δεδομένα δεν προάγονται αυτόματα σε verified.</small></div><div class="archive-list">${rows}</div>`;
}
renderEvidenceMaturity();

// v20 — public data contract + season/competition coverage matrix.
const PUBLIC_DATA_CONTRACT = Object.freeze({
  scoreRequires:['official_source','verified_status','integer_scores'],
  periodsRequire:['score_requirements','arithmetic_match'],
  playerSeasonTotalsRequire:['verified_identity','complete_known_schedule','complete_boxscore_coverage'],
  standingsRequire:['verified_results','official_rules','adjustments_ledger','official_snapshot_audit']
});
function coverageMatrix(){
 const map=new Map();
 for(const e of v18Ledger){
   const k=`${e.season}|${e.competition}`;
   if(!map.has(k)) map.set(k,{season:e.season,competition:e.competition,verified:0,sources:new Set(),status:'PARTIAL'});
   const r=map.get(k); r.verified++; r.sources.add(e.source);
 }
 return [...map.values()].map(r=>({...r,sources:r.sources.size})).sort((a,b)=>String(b.season).localeCompare(String(a.season))||a.competition.localeCompare(b.competition,'el'));
}
function runV20Audit(){
 const prior=runV19Audit(), errors=[...prior.errors], warnings=[...prior.warnings];
 for(const e of v18Ledger){
   if(e.verification==='verified' && (!Number.isInteger(e.homeScore)||!Number.isInteger(e.awayScore))) errors.push(`public-score-contract:${e.eventId}`);
   if(e.arithmetic===false) errors.push(`public-period-contract:${e.eventId}`);
 }
 for(const p of playerRegistry||[]){
   if(p.eokProfile && p.identityStatus!=='verified') errors.push(`unsafe-eok-link:${p.name}`);
   if((p.coverage||'').toLowerCase().includes('complete') && (p.verifiedGames||0)<=1) warnings.push(`player-completeness-review:${p.name}`);
 }
 return {pass:errors.length===0,errors,warnings};
}
function renderCoverageMatrix(){
 const host=document.querySelector('#coverageMatrix'); if(!host)return;
 const rows=coverageMatrix(); const audit=runV20Audit();
 host.innerHTML=`<div class="section-head"><div><small>V20 · COVERAGE CONTRACT</small><h2>Κάλυψη ανά σεζόν & διοργάνωση</h2></div></div><div class="${audit.pass?'verified-box':'audit-result bad'}"><b>${audit.pass?'✓ PUBLIC DATA CONTRACT PASS':'⛔ PUBLIC DATA CONTRACT BLOCKED'}</b><p>${audit.errors.length} critical errors · ${audit.warnings.length} review warnings</p><small>Καμία κατηγορία δεν χαρακτηρίζεται COMPLETE χωρίς αποδεδειγμένα πλήρες πρόγραμμα και επίσημο audit.</small></div><div class="archive-list">${rows.map(r=>`<article class="archive-item"><div><b>${esc(r.season)} · ${esc(r.competition)}</b><p>${r.verified} verified αγώνες · ${r.sources} επίσημες πηγές</p></div><span class="badge warn">${r.status}</span></article>`).join('')}</div>`;
}
renderCoverageMatrix();
