-- Lesvos Basket MVP schema (PostgreSQL / Supabase)
create type verification_status as enum ('verified','pending_review','source_conflict','rejected');
create type game_status as enum ('scheduled','live','final','postponed','cancelled');

create table sources (
  id bigserial primary key,
  name text not null,
  base_url text not null,
  is_official boolean not null default false,
  priority smallint not null default 100,
  created_at timestamptz not null default now()
);

create table competitions (
  id bigserial primary key,
  name text not null,
  season text not null,
  gender text check (gender in ('men','women','mixed')),
  age_group text not null default 'senior',
  unique(name, season)
);

create table teams (
  id bigserial primary key,
  canonical_name text not null unique,
  display_name text not null,
  island text,
  logo_url text,
  active boolean not null default true
);

create table team_aliases (
  id bigserial primary key,
  team_id bigint not null references teams(id) on delete cascade,
  alias text not null unique
);

create table games (
  id bigserial primary key,
  competition_id bigint references competitions(id),
  home_team_id bigint not null references teams(id),
  away_team_id bigint not null references teams(id),
  tipoff timestamptz,
  venue text,
  home_score smallint check (home_score >= 0),
  away_score smallint check (away_score >= 0),
  status game_status not null default 'scheduled',
  verification verification_status not null default 'pending_review',
  verified_at timestamptz,
  updated_at timestamptz not null default now(),
  check (home_team_id <> away_team_id),
  check ((status <> 'final') or (home_score is not null and away_score is not null))
);

create table game_evidence (
  id bigserial primary key,
  game_id bigint references games(id) on delete cascade,
  source_id bigint not null references sources(id),
  source_url text not null,
  source_published_at timestamptz,
  retrieved_at timestamptz not null default now(),
  raw_text text,
  parsed_payload jsonb not null default '{}'::jsonb,
  content_hash text,
  unique(source_url, content_hash)
);

create table players (
  id bigserial primary key,
  team_id bigint references teams(id),
  full_name text not null
);

create table player_game_stats (
  game_id bigint not null references games(id) on delete cascade,
  player_id bigint not null references players(id),
  points smallint not null default 0,
  ft_made smallint, ft_attempted smallint,
  two_made smallint, two_attempted smallint,
  three_made smallint, three_attempted smallint,
  fouls smallint,
  verification verification_status not null default 'pending_review',
  primary key (game_id, player_id),
  check (points >= 0),
  check (ft_made is null or ft_attempted is null or ft_made <= ft_attempted),
  check (two_made is null or two_attempted is null or two_made <= two_attempted),
  check (three_made is null or three_attempted is null or three_made <= three_attempted)
);

create table audit_log (
  id bigserial primary key,
  entity_type text not null,
  entity_id bigint not null,
  action text not null,
  before_data jsonb,
  after_data jsonb,
  reason text,
  created_at timestamptz not null default now()
);

insert into sources(name, base_url, is_official, priority) values
('Τ.Ε. ΕΟΚ Λέσβου','https://lesvosbasket.gr',true,10),
('Ελληνική Ομοσπονδία Καλαθοσφαίρισης','https://www.basket.gr',true,20);

-- v4: source-first ingestion and standings adjustments
create table if not exists standings_adjustments (
  id bigserial primary key,
  competition_id bigint,
  team_id bigint,
  season text not null,
  points_delta integer default 0,
  reason text not null,
  source_url text not null,
  verification_status text not null default 'pending_review',
  created_at timestamptz default now()
);

create table if not exists source_snapshots (
  id bigserial primary key,
  source_url text not null,
  source_type text not null,
  published_at timestamptz,
  fetched_at timestamptz default now(),
  content_hash text,
  raw_payload text,
  parser_version text,
  verification_status text not null default 'pending_review'
);

-- v7: verified player identity and external-source links
alter table players add column if not exists eok_profile_url text;
alter table players add column if not exists identity_status text default 'review_required' check (identity_status in ('verified','review_required','rejected'));
alter table players add column if not exists photo_url text;
alter table players add column if not exists photo_source_url text;
alter table players add column if not exists photo_usage_status text default 'not_cleared' check (photo_usage_status in ('cleared','not_cleared','external_only'));

create table if not exists player_identity_evidence (
  id bigserial primary key,
  player_id bigint references players(id) on delete cascade,
  source_url text not null,
  source_type text not null,
  evidence_json jsonb not null default '{}'::jsonb,
  decision text not null default 'pending' check (decision in ('pending','verified','rejected')),
  reviewed_at timestamptz,
  created_at timestamptz default now()
);

-- v8: verification workflow and hard publish gates
create table if not exists verification_reviews (
  id bigserial primary key,
  entity_type text not null check (entity_type in ('game','player','standing','box_score','source')),
  entity_id bigint,
  status text not null default 'review_required' check (status in ('review_required','verified','conflict','rejected')),
  reason text not null,
  evidence jsonb not null default '[]'::jsonb,
  reviewed_by text,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists publish_audits (
  id bigserial primary key,
  release_name text not null,
  critical_errors integer not null default 0 check (critical_errors >= 0),
  warnings integer not null default 0 check (warnings >= 0),
  report jsonb not null default '{}'::jsonb,
  passed boolean generated always as (critical_errors = 0) stored,
  created_at timestamptz not null default now()
);
