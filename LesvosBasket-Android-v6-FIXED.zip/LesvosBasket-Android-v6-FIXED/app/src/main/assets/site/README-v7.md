# Lesvos Basket MVP v7

## Νέα στο v7
- Player Registry στο δημόσιο UI.
- Verified player stats μόνο από επίσημα match reports της ΕΟΚ.
- Δεν μαντεύεται URL προφίλ αθλητή: απαιτείται identity verification.
- Φωτογραφία: placeholder μέχρι να υπάρχει σαφές δικαίωμα χρήσης / επιτρεπτή επίσημη πηγή.
- Μερικό dataset επισημαίνεται ως «Μερικό αρχείο» και δεν εμφανίζεται ως season/career total.
- Schema για EOK profile URL, identity evidence και photo usage status.

## Κανόνες ακρίβειας
1. Καμία αντιστοίχιση αθλητή μόνο από επώνυμο/όνομα.
2. Καμία αντιγραφή φωτογραφίας χωρίς clearance.
3. Τα στατιστικά συνδέονται με το συγκεκριμένο επίσημο match report.
4. Για ανήλικους δεν εμφανίζονται περιττά προσωπικά στοιχεία.
5. Αμφίβολες ταυτότητες μένουν `review_required`.

Ανοίξτε το `index.html` για το prototype.
