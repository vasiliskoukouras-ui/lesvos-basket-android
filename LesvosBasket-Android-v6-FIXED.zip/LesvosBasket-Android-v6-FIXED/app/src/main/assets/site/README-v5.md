# Lesvos Basket MVP v5

## Τι προστέθηκε
- Match Center με πραγματικά, επαληθευμένα σκορ από κείμενο της επίσημης Τ.Ε. ΕΟΚ Λέσβου.
- Tabs Σύνοψη / Ανά περίοδο / Box Score / Πηγή.
- Safe empty states: δεν δημιουργούνται box scores ή δεκάλεπτα όταν δεν υπάρχουν επίσημα στοιχεία.
- Data-quality dashboard.
- match-data.json για source-first αποθήκευση.
- Διατηρείται το Archive, History και Τουρνουά Αιγαίου.

## Κανόνας δημοσίευσης
HTML/text δεδομένα μπορούν να γίνουν verified μετά από validation. Δεδομένα που υπάρχουν μόνο σε εικόνα/πίνακα παραμένουν pending review μέχρι χειροκίνητη επιβεβαίωση.

## Επόμενο production βήμα
Μεταφορά του static dataset σε Supabase/PostgreSQL και scheduled importer με review queue.
