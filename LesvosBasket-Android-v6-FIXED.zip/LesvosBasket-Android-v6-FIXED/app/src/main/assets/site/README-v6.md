# Lesvos Basket MVP v6

Polished source-first prototype for Lesvos/Lemnos basketball.

## v6 changes
- Removed fabricated weekly fixtures/standings from the public UI.
- Added responsive production-style navigation and visual system.
- Added verified game filtering by season/competition.
- Improved Match Center with explicit unavailable-data states for periods/box scores.
- Added Archive season navigator and History timeline.
- Added real official Tournament of the Aegean schedule subset and official streams.
- Added data-quality explanation (snapshots, validation, review queue, audit trail).
- Added latest official-source activity card for 14 Sep 2026.

## Accuracy rule
A result is marked VERIFIED only when the score is explicitly available in official textual source material. Image-only standings/results must remain pending review until manually validated.

## Next production integration
Connect `schema.sql` + `importer.js` to Supabase/PostgreSQL and run imports server-side. Add authenticated admin review before publishing pending records.
