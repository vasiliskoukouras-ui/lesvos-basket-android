# Lesvos Basket MVP v12

## New in v12
- Expanded verified dataset with official EOK games involving Lesvos/Lemnos clubs.
- Added verified quarter-by-quarter data for Pramnos Ikarias–Ifaistos Lemnou 44–71 (04/04/2026).
- Added partial, match-level scorer records for Ifaistos; identities remain REVIEW_REQUIRED and are never presented as season totals.
- Added Gen A Stars U16 AL Mytilini–Ifaistos Lemnou 71–46 from EOK schedule.
- New `v12-integrity.js` release audit: duplicate IDs, official-source allowlist, score validity, period arithmetic, coverage claims and unsafe player links.
- Fail-closed remains mandatory: any critical integrity issue => BLOCKED.

Run `node test-v12.js`.
