# Lesvos Basket MVP v18

Production-readiness hardening build.

- Canonical event ledger derived only from verified public-layer matches.
- Semantic duplicate detection using season + competition + date + canonical teams.
- Provenance required for every verified event.
- Arithmetic failures block release.
- REVIEW_REQUIRED source-inbox items cannot be promoted into the public numeric ledger.
- Coverage remains explicit: partial is never presented as complete.
- Latest TE Lesvos 12/09/2026 result post remains review-only because retrievable text does not expose a safely verifiable score.

Core policy: fail closed; unknown != zero; official post != verified field; partial != complete.
