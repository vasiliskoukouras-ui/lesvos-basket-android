# Lesvos Basket MVP v9 — Zero-error oriented release gate

v9 adds an immutable-style provenance ledger, deterministic source priority, source-conflict blocking, and a release gate on top of v8's Verification Center.

## Publication policy
- Official text/result evidence can be VERIFIED after structural validation.
- Image-only values remain REVIEW_REQUIRED until manually validated.
- Two verified official values that disagree become SOURCE_CONFLICT; no automatic winner is published.
- Later/final official recap has higher priority only when values do not conflict; priority never hides a conflict.
- Player EOK links/photos remain forbidden unless identity_status is VERIFIED.
- Partial match stats cannot be represented as season/career totals.
- Critical integrity errors or unresolved source/identity conflicts block release.

## v9 modules
- `conflict-engine.js`: evidence resolver and source priority.
- `integrity-tests.js`: reusable publication validators.
- `app.js`: prototype provenance ledger + release gate UI.

Absolute zero error cannot be guaranteed because official sources can themselves be corrected, but the app is fail-closed: uncertain/conflicting data is withheld rather than guessed.
