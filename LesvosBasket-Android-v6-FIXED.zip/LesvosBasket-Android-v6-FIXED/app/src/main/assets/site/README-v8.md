# Lesvos Basket MVP v8 — Verification Center

v8 adds a local Admin/Data Health prototype and hard publish-gate logic.

## New
- Identity review queue for every current player record.
- Greek-name normalization helper, but **never auto-verifies identities**.
- Hold/reject workflow for uncertain player matches.
- Integrity audit for official source presence, score types/ranges, duplicate games, unsafe EOK links, and explicit partial-stat coverage.
- Data Health counters and publish gates in the UI.
- Database tables for verification reviews and release audits.

## Zero-error policy
Absolute zero error cannot be guaranteed because official sources can be corrected later. The product rule is therefore fail-closed: uncertain/conflicting data is blocked from normal publication until reviewed.

## Player rule
No EOK player-profile URL or photo is attached merely from a matching surname/name. The official EOK athlete list is an identity source, not permission to auto-link ambiguous records.
