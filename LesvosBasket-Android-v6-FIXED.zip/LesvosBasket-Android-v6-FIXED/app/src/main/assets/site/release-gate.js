/* Lesvos Basket v11 — fail-closed release gate */
(function(root){
 function evaluate({games=[],players=[],conflicts=[],integrityIssues=[]}={}){
   const blockers=[];
   for(const g of games){if(g.public===true && (g.verification_status!=='verified'||!g.source_url)) blockers.push({type:'unsafe_public_game',id:g.id||null});}
   for(const p of players){if((p.eok_profile_url||p.photo_url)&&p.identity_status!=='verified') blockers.push({type:'unsafe_player_identity',id:p.id||p.name||null});}
   for(const c of conflicts){if(c.status!=='resolved') blockers.push({type:'unresolved_source_conflict',id:c.id||null});}
   for(const i of integrityIssues){if(i.severity==='critical') blockers.push(i);}
   return {status:blockers.length?'BLOCKED':'PASS',blockers};
 }
 const api={evaluate};if(typeof module!=='undefined')module.exports=api;root.LesvosReleaseGate=api;
})(typeof window!=='undefined'?window:globalThis);
