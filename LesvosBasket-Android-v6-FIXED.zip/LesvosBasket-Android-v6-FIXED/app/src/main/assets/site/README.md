# Lesvos Basket MVP
Πρώτο λειτουργικό responsive prototype.

## Εκτέλεση
Ανοίξτε το `index.html` σε browser ή τρέξτε έναν απλό local HTTP server.

## Επόμενο development sprint
1. Next.js app structure
2. PostgreSQL/Supabase schema
3. Official-source importer (Τ.Ε. ΕΟΚ Λέσβου + ΕΟΚ)
4. Game details + box scores
5. Admin validation panel

Σημείωση: τα δεδομένα της τρέχουσας έκδοσης είναι mock data και δεν παρουσιάζονται ως επίσημα.


## Sprint 2 — Data integrity layer
Προστέθηκαν `schema.sql`, `validator.js` και `validation-demo.html`.

### Αρχή ασφαλείας δεδομένων
- Καμία εγγραφή χωρίς επίσημη πηγή δεν γίνεται verified.
- Μία επίσημη πηγή παραμένει pending_review.
- Δύο επίσημες πηγές με ίδιο τελικό σκορ μπορούν να γίνουν verified.
- Σύγκρουση επίσημων πηγών γίνεται source_conflict και δεν δημοσιεύεται αυτόματα.
- Κρατείται raw evidence και audit log ώστε κάθε διόρθωση να είναι ανιχνεύσιμη.

## v3 — Archive / History
Added Archive and History sections, source-backed season cards, official-source links, archive quality states, and a machine-readable archive-data.json policy file. No image-only standings are transcribed automatically into public data until validation.

## v4 development update (2026-09-15)
- Added source-first importer core (`importer.js`): imported records are candidates and cannot auto-publish.
- Added `source_snapshots` and `standings_adjustments` schema for provenance, corrections, penalties and auditability.
- Added `official-data.json` with a small verified seed dataset from official Τ.Ε. ΕΟΚ Λέσβου pages.
- Added an official Tournament section using published 2025–26 Aegean Tournament schedule/stream links.
- Current generic weekly games/standings remain clearly marked mock UI until verified structured ingestion is complete.

### Safety rule for data quality
Never infer a score, standing, player stat, champion or penalty from an image-only source without review. Preserve source URL and raw snapshot; publish only after validation/approval.
