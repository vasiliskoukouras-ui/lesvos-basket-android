const fs=require('fs');
const s=fs.readFileSync('app.js','utf8'), h=fs.readFileSync('index.html','utf8');
const checks=[
 ['v20 audit',s.includes('function runV20Audit()')],
 ['public data contract',s.includes('PUBLIC_DATA_CONTRACT')],
 ['coverage matrix',s.includes('function coverageMatrix()')],
 ['coverage UI',h.includes('id="coverageMatrix"')],
 ['no automatic complete',s.includes("status:'PARTIAL'")],
 ['unsafe EOK link guard',s.includes('unsafe-eok-link')]
];
const bad=checks.filter(x=>!x[1]);
console.log(checks.map(x=>`${x[1]?'PASS':'FAIL'} ${x[0]}`).join('\n'));
if(bad.length) process.exit(1);
