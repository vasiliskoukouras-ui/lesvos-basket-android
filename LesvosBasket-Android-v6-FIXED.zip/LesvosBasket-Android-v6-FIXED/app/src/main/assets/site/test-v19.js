const fs=require('fs');
const s=fs.readFileSync('app.js','utf8');
const h=fs.readFileSync('index.html','utf8');
const checks=[
 ['v19 audit',s.includes('function runV19Audit()')],
 ['evidence maturity',s.includes('evidenceMaturity')],
 ['image review guard',s.includes('latest-image-result-must-remain-review')],
 ['UI mount',h.includes('id="evidenceMaturity"')],
 ['review source retained',s.includes('te-2026-09-14-result')&&s.includes("status:'review_required'")]
];
const bad=checks.filter(x=>!x[1]);
console.log(checks.map(x=>`${x[1]?'PASS':'FAIL'} ${x[0]}`).join('\n'));
if(bad.length)process.exit(1);
