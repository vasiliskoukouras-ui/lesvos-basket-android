const fs=require('fs'); const data=JSON.parse(fs.readFileSync('./v12-data.json','utf8')); const {audit}=require('./v12-integrity');
const r=audit(data); console.log(JSON.stringify(r,null,2)); if(!r.ok) process.exit(1);
