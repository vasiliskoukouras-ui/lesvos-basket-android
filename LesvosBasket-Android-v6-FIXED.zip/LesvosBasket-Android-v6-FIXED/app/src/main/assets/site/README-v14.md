# Lesvos Basket MVP v14

## Νέα έκδοση
- Team data layer με coverage ανά ομάδα και διοργάνωση.
- Coverage Dashboard ανά σεζόν, με σαφή ένδειξη `partial` αντί για ψευδή πληρότητα.
- Release gate που απαγορεύει αυτόματη δημοσίευση αριθμών από image-only αναρτήσεις.
- Διατηρεί unresolved source conflicts και unverified player identities εκτός public verified layer.
- Νέο `v14-integrity.js` για fail-closed regression checks.

## Αρχή
Το coverage μετρά μόνο ό,τι έχει επαληθευτεί. Η απουσία δεδομένων δεν μετατρέπεται σε 0 και ένα μερικό dataset δεν παρουσιάζεται ως πλήρης σεζόν.
