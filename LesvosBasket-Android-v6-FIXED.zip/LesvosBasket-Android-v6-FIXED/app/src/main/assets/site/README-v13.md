# Lesvos Basket MVP v13

## Τι προστέθηκε
- Επέκταση του public verified dataset μόνο από επίσημες πηγές Τ.Ε. ΕΟΚ Λέσβου και ΕΟΚ.
- Αθλητική Λέσχη Μυτιλήνης–ΑΟ Κολοσσός 48–76 (15/05/2026), με verified δεκάλεπτα και arithmetic audit.
- Τελικός Κυπέλλου Ανδρών 2025–26: Αθλητική Λέσχη Μυτιλήνης–Παλλεσβιακός ΠΓ 62–67.
- Cross-source confirmation για τον ΑΟ Ήφαιστος Λήμνου ως πρωταθλητή Εφήβων ΤΕ Λέσβου 2025–26.
- `v13-data.json`: machine-readable verified dataset.
- `v13-integrity.js`: fail-closed checks για official domains, scores, period sums, duplicate IDs και cross-source facts.

## Πολιτική ακρίβειας
Δεν γίνεται εξαγωγή αριθμών από image-only standings/results για αυτόματη δημόσια δημοσίευση. Τέτοιες αναρτήσεις παραμένουν review-required. Cross-source verification αυξάνει την τεκμηρίωση, αλλά δεν χρησιμοποιείται για να κρύψει πραγματική σύγκρουση πηγών.
