/* Lesvos Basket v11 — deterministic standings engine */
(function (root) {
  const n = v => Number.isFinite(Number(v)) ? Number(v) : 0;
  function baseRow(team){return {team,played:0,wins:0,losses:0,for:0,against:0,basePoints:0,adjustment:0,points:0,diff:0};}
  function calculateStandings(games, adjustments=[], rules={win:2,loss:1,forfeitLoss:0}) {
    const rows = new Map();
    const get=t=>{if(!rows.has(t)) rows.set(t,baseRow(t)); return rows.get(t)};
    for (const g of games||[]) {
      if(g.verification_status!=='verified'||g.status!=='final') continue;
      if(!Number.isInteger(g.home_score)||!Number.isInteger(g.away_score)||g.home_score<0||g.away_score<0) continue;
      const h=get(g.home_team), a=get(g.away_team); h.played++;a.played++;h.for+=g.home_score;h.against+=g.away_score;a.for+=g.away_score;a.against+=g.home_score;
      if(g.home_score>g.away_score){h.wins++;a.losses++;h.basePoints+=rules.win;a.basePoints+=g.away_forfeit?rules.forfeitLoss:rules.loss;}
      else if(g.away_score>g.home_score){a.wins++;h.losses++;a.basePoints+=rules.win;h.basePoints+=g.home_forfeit?rules.forfeitLoss:rules.loss;}
    }
    for(const adj of adjustments||[]){if(adj.verification_status!=='verified') continue; const r=get(adj.team); r.adjustment+=n(adj.points_delta);}
    return [...rows.values()].map(r=>({...r,points:r.basePoints+r.adjustment,diff:r.for-r.against})).sort((x,y)=>y.points-x.points||y.diff-x.diff||y.for-x.for||x.team.localeCompare(y.team,'el'));
  }
  function auditStandings(calculated, official){const issues=[]; const by=new Map((calculated||[]).map(r=>[r.team,r])); for(const o of official||[]){const c=by.get(o.team);if(!c){issues.push({team:o.team,type:'missing_team'});continue;} for(const k of ['played','wins','losses','points']) if(Number.isInteger(o[k])&&c[k]!==o[k]) issues.push({team:o.team,type:'standing_mismatch',field:k,calculated:c[k],official:o[k]});} return {ok:issues.length===0,issues};}
  const api={calculateStandings,auditStandings}; if(typeof module!=='undefined') module.exports=api; root.LesvosStandings=api;
})(typeof window!=='undefined'?window:globalThis);
