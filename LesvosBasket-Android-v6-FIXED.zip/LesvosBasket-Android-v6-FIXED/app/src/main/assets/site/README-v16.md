# Lesvos Basket MVP v16

## Added
- Richer verified Match Center with period-by-period display when official text provides it.
- Arithmetic audit for quarters/overtime against final score.
- Verified 05/04/2026 Ήφαιστος Λήμνου–ΦΟ Βροντάδου 62–60 (OT), official EOK source.
- Verified 24/02/2024 Ήφαιστος–Αίολος 60–56 with four quarters, official TE Lesvos source.
- Team Season View: counts only verified public-layer games and always labels incomplete coverage PARTIAL.
- v16 release audit: duplicate IDs, official-source allowlist, score validation, period-total validation.

## Fail-closed rules
Unknown is not zero. Partial is not complete. Image-only numeric data is not promoted automatically. Unresolved identity/source conflicts remain blocked.
