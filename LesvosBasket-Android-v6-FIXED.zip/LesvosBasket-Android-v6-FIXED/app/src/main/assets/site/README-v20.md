# Lesvos Basket MVP v20

Public-data-contract and coverage hardening build.

- Adds a formal public data contract for scores, periods, player season totals and standings.
- Adds season/competition coverage matrix; all current groups remain PARTIAL unless completeness is independently proven.
- Adds release checks preventing unsafe EOK profile links and invalid public scores.
- Retains image-only official posts in REVIEW_REQUIRED.
- No missing value is converted to zero and no partial dataset is labelled complete.
