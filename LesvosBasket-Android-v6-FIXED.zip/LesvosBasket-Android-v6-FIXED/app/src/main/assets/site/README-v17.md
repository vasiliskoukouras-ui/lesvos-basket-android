# Lesvos Basket MVP v17

Production-hardening build.

- Source Inbox for official TE Lesvos / EOK publications.
- Freshness guard: discovering a new official post does not promote its numeric contents automatically.
- Image-only numeric posts remain REVIEW_REQUIRED.
- Separate content modes: text_claim, text_schedule, text_result_box, image_only_numeric.
- v17 audit rejects unsafe image-to-verified promotion and non-official source domains.
- Latest official TE Lesvos result post (14/09/2026 for 12/09/2026) is intentionally retained as review_required because the retrievable text does not safely expose the score.

Core rule: unknown != zero; official post != verified field; partial != complete.
