export const SOURCE_PRIORITY = Object.freeze({official_final_recap:100,official_result_text:90,official_schedule:70,official_image:50});
export function canonical(v=''){return String(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/\s+/g,' ').trim()}
export function resolveOfficialEvidence(evidence=[]){
 const verified=evidence.filter(e=>e.status==='verified');
 const values=new Set(verified.map(e=>canonical(e.value)));
 if(values.size>1)return {status:'source_conflict',publish:false};
 if(!verified.length)return {status:'review_required',publish:false};
 const best=[...verified].sort((a,b)=>(SOURCE_PRIORITY[b.kind]||0)-(SOURCE_PRIORITY[a.kind]||0)||String(b.published||'').localeCompare(String(a.published||'')))[0];
 return {status:'verified',publish:true,evidence:best};
}
